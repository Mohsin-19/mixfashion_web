Enter
View Details
Edit
Add
Delete
Address
Phone
Started Date
Yes
No
Submit
Back
Low
Are you sure
SN
Actions
OK
Cancel
Information has been added successfully!
Information has been updated successfully!
Information has been deleted successfully!
Please click on green Enter button of an outlet
Register is not open, enter your opening balance!
User is not active
Incorrect Email/Password
Password has been changed successfully!
Old Password does not match!
Back
POS Setting
All Screens
Outlets
Add Outlet
POS Setting
Outlet Code
Shop Name
Not for login, for showing in print receipt
Invoice Footer
Collect VAT
I Collect Tax
Show sample invoice with tax
My Tax Title
Show how Tax Title works
My Tax Registration No
My Tax is GST
What will happen if I say Yes
State Code
My Tax Fields
Add More
Show How tax fields work
VAT Registration Number
Pre or Post Payment
Post Payment
Pre Payment
Open Register
Opening Balance
Dashboard
Business Intelligence
Products
Manage
Products
Customers
Employees
Quick Links
Product
Supplier Payment
POS
Expense
Purchase
Daily Summary Report
Register Report
Profit Loss Report
Sale Report
Sale Report
Send SMS
Stock
Stock Adjustment
Customer Receive
Attendance
Dine In
Take Away
Delivery
This Month
Operational Comparision
Products in Low
Low Stock
Product Name
Current Stock
Top 10 Products This Month
Name
Count
Top 10 Customers This Month
Customer Name
Sale Amount
Customer Receivables
Due Amount
Supplier Payables
Supplier Name
Monthly Sale Comparison
Cust Rcv
Supp Pay
Purchases
Add Purchase
Reference No
Date
Supplier
G. Total
Due
Added By
Unit Price
The Supplier field is required.
The Date field is required.
The Paid field is required.
Edit Purchase
Purchase Details
Exceeding available sit!!
Seat number must be greater than zero!!!
Are you sure to cancel this booking?
Are you sure to delete all notifications?
No notification is selected
error
Are you sure to delete all hold sales?
There is no hold!
Are you sure to delete this hold?
Please select a Hold Sale to proceed!
Delete is only allowed for Admin
Are you sure to delete this order?
Are you sure to cancel this order?
Please select an order to proceed!
Cart is not empty, want to proceed?
Cart is not empty, want to clear the cart?
You can not remove or modify any product that is In Progress or Done in Kitchen
Order is In Progress or Done, you can not cancel it!
You can not close an order without invoicing!
Do you want to close this order?
Please select an Open Order to proceed!
Cart is empty!
Please select A Customer!
Please select A Waiter!
Delivery is not possible for Walk-in Customer, please choose another!
For Delivery order, customer must has a Delivery Address!
You must select Dine In or Take Away or Delivery!
Order has been added to Running Orders and went to Kitchen Panel as well. Select any order from Running Orders to modify it or create invoice
Sale
Add Sale
Order Type
Order Number
Order No
Time
Customer
Total Payable
Payment Method
View Invoice
Change Date
Save changes
Close
Modified
Modifiers
Date
Product Name
Cool Haus
Cool Haus 2
First Scoo
First Scoo 2
Modifier
Modifier 2
Mg
Mg 2
Add to Cart
Add Customer
Name
Email
DOB
DOA
Delivery Address
New
Tables
Proceed without Table
Order Placed at
Order Table
Status
Please Read
Modify Order
If you need to add some new product to an order, please select a running order from left and click on Modify Order. We have a perfect mechanism for modifying an order, please do that from there and please dont be confused to do that here, this is only table management section of an order.
What you can do here
An order may contain many person sitting in multiple tables, so you can select multiple tables for an order You can not set person more than available sit for in a table You can proceed without selecting table because some people may can gather, take tea and go out As a table can have availability of several chairs and sometime those are sharable, so you can select multiple order in a table
Finalize Sale
Total Payment
Pay Amount
Given Amount
Change Amount
Open Hold Sales
Hold Sale
Walk-In-Customer
Hold Number
Delete all Hold Sales
Order Type
Edit in Cart
Kitchen, Waiter & Bar
Kitchen Panel
Panels
Waiter Name
Invoice
Help
Cook
Done
You should click on one/multiple product to mark it as Started Cooking or Done.
 You can not select any product for Take Away or Delivery type orders, as you need to deliver these type of orders as a pack Blue color indicates Started Cooking, where green color indicates that the product is Done cooking.
Until an order is closed from POS Panel, that order will remain here
Notification
Notification List
Select All
Unselect All
Serve/Take/Delivery
Waiter Panel
You should click on one/multiple product to mark it as Started Preparing or Done.
You can not select any product for Take Away or Delivery type orders, as you need to deliver these type of orders as a pack Blue color indicates Started Preparing, where green color indicates that the product is Done cooking.
Until an order is closed from POS Panel, that order will remain here
Remove
Collect
Bar Panel
Prepare
Calculator
Read Before Begin
What is Running Order 
Placed order goes to Running Orders, to modify/invoice that order just select that order and click on bellow button 
What is Modify Order 
Modify order is not limited to only add new product, means modification of anything of that order, remove product, change product qty, change type, change waiter etc
Allow Popup 
Please allow popup of your browser to print Invoice and KOT 
Print KOT 
Use Print KOT button if you intend to not to use Kitchen Panel 
When customer asks for new product or he wants an product more, just modify an order then go to print KOT, and just check that new product/quantity increased product, then reduce quantity and print the KOT, so that you can now only send the new product to kitchen
But for Kitchen Panel, no need to worry, kithcen panel will be notified when an order is modified 
Searching 
Press Ctrl+Shift+F to focus on Search field 
Just type VEG, all veg products will be appeared
Just type BEV, all beverage products will be appeared
Just type Bar, all bar products will be appeared
Refresh Button 
When you see that there refresh button right beside of running orders is red. You need to click on that button to refresh running orders to get update from kitchen. 
Stock
System will only deduct product from inventory when you close an order by clicking on Create Invoice & Close OR Close Order button.
Order Details 
You can also see an orders details by double clicking on it
Discount 
Mention that discount does not applies on Modifier. 
Clear Cache 
We are using JS cache to speed up operation, so please clear your cache by Ctrl+F5 after adding a new Product.
Last 10 Sales
Sale No
Print Invoice
Invoice No
Kitchen Notification
Dashboard
Register
Logout
Running Orders
Started Cooking
Time Count
Table, Order Number, Waiter, Customer
Hold Details
KOT
Print KOT
Create Invoice & Close
Create Invoice
Close Order
Modify Order/Add Product/Change Table
Cancel Order
Kitchen Status
Waiter
Table
Product
Price
Qty
Discount
Total
Total Product
Sub Total
Tax
Total Discount
Shipping/Other
Shipping/Other
Cancel
Hold
Direct Invoice
Payment
Name or Code or Category or VEG or BEV or BAR
Please select an order to proceed
Register closed successfully
You are only a POS User, you can not go to dashboard
Select Product
Add Product
Barcode
Payment
Open Hold Sales
Hold Sales
Delete all Hold Sales
Delete all Hold Sales
Date of Birth
Date of Anniversary
Code
Category
Product
Stock Value
Stock Qty/Amount
Low Qty/Amount
Stock Adjustments
Add Stock Adjustment
Product Count
Responsible Person
Note
Read Me First
Quantity/Amount
Consumption Status
Select
Consumption Amt
NOTICE
You must enter the Quantity/Amount in the Unit showing just right after the Quantity/Amount field, otherwise Stock will not match.
Click Here
Product already remains in cart, you can change Quantity/Amount
Edit Stock Adjustment
Stock Adjustment Details
The Responsible Person field is required.
The Note field cannot exceed 200 characters in length.
Damages
Add Damage
Total Loss
Product Damage Quantity
Product Damage
Wast Quantity
Only purchased Products are listed
Loss Amount
Loss Amt
Damage Amt
Edit Damage
Damage Details
Expenses
Add Expense
Edit Expense
Category
Amount
Supplier Due Payments
Add Supplier Due Payment
Supplier
Customer Due Receives
Add Customer Due Receive
SMS Service, please choose option from below
Signup in TextLocal
Configure SMS
Send Test SMS
Check Balance
SMS to Customers Who Have Birthday Today
SMS to Customers Who Have Anniversary Today
Send Custom SMS to all Customers
Please be informed that you need to verify your TextLocal account before using that here to send sms from this software. First create account in TextLocal, then contact their support to verify it.
SMS Settings
Provide your TextLocal https://www.textlocal.com/ SMS Credentials
Email Address
Password
Go to Send SMS Page
Send
SMS
Number
Must include country code, otherwise sms will fail
Message
There are
customer has
today
Only
customer has valid phone number, you can send sms to these customers.
 Your Current Credit Balance
Please make sure that your current balance is sufficient to send sms.
SMS Balance
Your current textlocal sms credit balance is
please check in
TextLocal
to know how many sms you can send by this credit.
Attendances
Add Attendance
Employee
In Time
Out Time
Update Time
Time Count
Add/Update Attendance
Cash:
Paypal:
Card:
Start Date
End Date
User
Opening Date & Time
Closing Date & Time
Paid Amount
Opneing Balance
Closing Balance
Customer Due Receive
Sale In Payment Methods
Daily Summary Report
Print
Sum
Paid
Sales
Sales Report
Quantity
Daily Sale Report
Sale Report
Total Sale
Date:
Detailed Sale Report
Reference
All
Subtotal
Total Products
Consumption Report
Consumption Report of Menus
Consumption Report of Modifiers
Stock Report
Profit Loss Report
Only Paid Amount
Supplier Due Payment
Damage
Gross Profit
Net Profit
Vat Report
Kitchen Performance Report
Type
Order Time
Cooking Start Time
Cooking End Time
Time Taken
Hour
Attendance Report
Hours
Supplier Report
Suppliers
Due Payment
Payment Amount
Supplier Ledger Report
Supplier Due Report
Payable Due
Customer Due Report
Customer Report
Customer Ledger Report
Receive Amount
Due Receive
Purchase Report
Grand Total
Purchased By
Expense Report
Expense Product
Damage Report
Product Categories
Add Product Category
Edit Product Category
Name
Description
Add Unit
Units
Unit
Unit Name
Add Product
Upload Product
Product Barcode
Upload Products
Upload
Upload File
Download Sample
Remove all prevoius data, before uploading new data.
Low Quantity/Amount
Purchase Price
Low Qty
Low Quantity
The unit you purchase with, eg: Packet, KG, L etc
The unit you sale with, eg: Piece, g, ml etc
1 Purchase Unit equals to how many Sale Unit, eg: 1 Packet = 12 pcs, 1 KG = 1000 g
Your purchase price NB: in purchase unit
Your sale price NB: in sale unit, not in purchase unit
Which amount you commonly sale, you set that to sale faster, eg: your customer usually purchases 5pcs Pen from you, then you dont need to change Qty/Amt every time in sale page, you write 5 here, when you add pepper in cart, 50 will be set automatically in Qty/Amt in Cart
VATs
Add VAT
VAT Name
Percentage
Modifier
Price
Product Consumptions
Consumption
The Name field is required.
The Price field is required.
At least 1 Product is required.
The Description field cannot exceed 200 characters in length.
Modifier Details
Product Categories
Add Product Category
Edit Product Category
Products
Add Product
Upload Product
Upload Recipe
Type
Product
Service
Purchase Unit
Sale Unit
Conversion Rate
Purchase Price
Sale Price
Usual Sale Qty/Amt
Total Products
Assign Modifier
Photo
Is it Veg Product
Is it Beverage
Is it Bar Product
The Category field is required.
The Sale Price field is required.
The Is it Veg Product? field is required.
The Is it Beverage? field is required.
The Is it Bar Product? field is required.
Edit Product
Height must be 80px and Width must be 142px
Product Details
Assign Product Modifier
Add Supplier
Contact Person
Edit Supplier
Add Customer
Upload Customer
Should contain country code
Date Of Birth
Date Of Anniversary
GST Number
Edit Customer
Expense Products
Add Expense Product
Expense Product Name
Edit Expense Product
Add Employee
Designation
Enter Customer for Customer Panel, to be appeared in waiter dropdown in POS screen
Edit Employee
Payment Methods
Add Payment Method
Payment Method Name
Edit Payment Method
Outlet
Add Table
Table Name
Seat Capacity
Position
Edit Table
General Settings
Date Format
Country Time Zone
Currency
Short Message Service
Users
Bar
Kitchen
Add User
Activate
Deactivate
Email Address
Password
Confirm Password
Designation
Will Login?
POS User
Kitchen User
Bar User
Waiter User
Menu Access
Edit User
User has been activated successfully! This user will be able to login again.
User has been deactivated successfully! This user will no longer be able to login.
Change Profile
Change Password
Old Password
New Password
Login
Please Login
POS
Todays Summary
Shortcut Keys
Register Details
Close Register
Language
MAIN NAVIGATION
Home
Outlet List
Purchase
Stock Adjustments
Damage
Expense
Supplier Due Payment
Customer Due Receive
Send SMS
Attendance
Report
Sale Report
Low Stock Report
Supplier Ledger
Customer Ledger
Product
Units
Setting
SMS Setting
Manage Users
in
Cash
Card
Paypal
Not Closed Yet
to
Service Sale Report
Quotation
Quotations
Add Quotation
Edit Quotation
Remark
Other
Low Qty/Amt
Product Low
Opening Stock
White Label
System Title
System Footer
Login Logo
Admin Panel Logo
Please select a Purchase Unit and Sale Unit
You can not edit Walk-in Customer
Copy
Send Invoice SMS
Send Invoice Email
Search Records
Showing
to
from
entries
First
Last
Next
Prev
No data available in table
No matching records found
GST Number
Date Of Anniversary
Date Of Birth
Add Customer
Successfully sent email
Date Time
Keyboard Shortcuts
Image size should be width: 128px & height: 49px
Ref
Calculated based on last purchase price and Product with negative Stock Qty/Amt is not considered
In sale unit
Crop
Select Image
add image
Please select a image
Due is not acceptable for Walk-in Customer 